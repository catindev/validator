# Validator prototype tests

Two suites:
1) Engine core features (per "Допик к БТ - flat v3")
2) BT validation before sending to ABS (field validation logic via pipelines)

## How to run (Node >= 20)
From project root (where `index.js` and `rules/` are):
```bash
node tests/run.js
```

The runner executes the engine as CLI and asserts on JSON output.

Notes:
- The runner is pure Node (no Jest/Mocha), to keep stack minimal.
- Some engine-feature tests temporarily create small test pipelines under `rules/pipelines/<ver>/_engine_tests/...`
  and remove them after the test run.
