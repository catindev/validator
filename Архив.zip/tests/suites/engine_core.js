const path = require("path");
const fs = require("fs");
const { readJson, writeJson, rmrf, assert, deepEqual, runEngine } = require("../lib/utils");

function projectRoot() {
  // tests folder lives alongside index.js
  return path.resolve(__dirname, "..", "..");
}

function rulesRoot() {
  return path.join(projectRoot(), "rules");
}

function manifest() {
  return readJson(path.join(rulesRoot(), "manifest.json"));
}

function pipelinesVersion() {
  return String(manifest().pipelines_version);
}

function pickExistingPipeline() {
  const base = path.join(rulesRoot(), "pipelines", pipelinesVersion());
  const dirs = fs.readdirSync(base, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => d.name)
    .filter(n => !n.startsWith("_"));
  assert(dirs.length > 0, "No pipelines found under " + base);
  // Prefer demo if exists, else first real pipeline
  if (dirs.includes("demo")) return "demo";
  return dirs[0];
}

function bodyOk() {
  return "tests/fixtures/engine/body_ok.json";
}

function bodyBad() {
  return "tests/fixtures/engine/body_bad.json";
}

async function runEngineSuite() {
  console.log("\n== Suite 1: Engine core features ==");

  const pipe = pickExistingPipeline();

  // 1) happy-path: existing pipeline returns JSON
  {
    const { parsed } = runEngine([`/${pipe}`, bodyOk()], projectRoot());
    assert(parsed && parsed.status, "Expected status in response");
  }

  // 2) pipeline not found -> EXCEPTION with PIPELINE_NOT_FOUND
  {
    const { parsed } = runEngine(["/no_such_pipeline", bodyOk()], projectRoot());
    assert(parsed.status === "EXCEPTION", "Expected EXCEPTION status");
    assert(parsed.errors && parsed.errors[0] && parsed.errors[0].code === "PIPELINE_NOT_FOUND", "Expected PIPELINE_NOT_FOUND");
  }

  // 3) deterministic output (same input -> same output)
  {
    const a = runEngine([`/${pipe}`, bodyBad()], projectRoot()).parsed;
    const b = runEngine([`/${pipe}`, bodyBad()], projectRoot()).parsed;
    assert(deepEqual(a, b), "Expected deterministic JSON output for same input");
  }

  // 4) library namespace validation: non-library dotted ref should error IMPORT_FORMAT_INVALID
  // We create a tiny pipeline that references "common.something" (invalid namespace) and run it.
  const testBase = path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests", pipelinesVersion());
  rmrf(path.dirname(testBase)); // cleanup in case of previous run
  try {
    const pipeDir = path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests", pipelinesVersion());
    writeJson(path.join(pipeDir, "index.json"), [
      { "rule": "common.contacts_any" }
    ]);
    const { parsed } = runEngine([`/_engine_tests/${pipelinesVersion()}`, bodyOk()], projectRoot());
    assert(parsed.status === "EXCEPTION", "Expected EXCEPTION");
    assert(parsed.errors[0].code === "IMPORT_FORMAT_INVALID", "Expected IMPORT_FORMAT_INVALID for non-library dotted ref");
  } finally {
    rmrf(path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests"));
  }

  // 5) group forbids BLOCK/EXCEPTION by declaration (should fail on DSL validation)
  rmrf(path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests"));
  try {
    const pipeDir = path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests", pipelinesVersion());
    writeJson(path.join(pipeDir, "index.json"), [
      [
        { "rule": "libriary.tax.blk_tin_country_usa" }
      ]
    ]);
    const { parsed } = runEngine([`/_engine_tests/${pipelinesVersion()}`, bodyOk()], projectRoot());
    assert(parsed.status === "EXCEPTION", "Expected EXCEPTION");
    assert(parsed.errors[0].code === "GROUP_FORBIDS_LEVEL", "Expected GROUP_FORBIDS_LEVEL");
  } finally {
    rmrf(path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests"));
  }

  // 6) pipeline cycle detection (library pipelines)
  const libVer = String(manifest().library_version);
  const libDir = path.join(rulesRoot(), "library", libVer, "_engine_tests");
  rmrf(libDir);
  rmrf(path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests"));
  try {
    writeJson(path.join(libDir, "a.json"), [{ "pipeline": "libriary._engine_tests.b" }]);
    writeJson(path.join(libDir, "b.json"), [{ "pipeline": "libriary._engine_tests.a" }]);

    const pipeDir = path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests", pipelinesVersion());
    writeJson(path.join(pipeDir, "index.json"), [
      [ { "pipeline": "libriary._engine_tests.a" } ]
    ]);

    const { parsed } = runEngine([`/_engine_tests/${pipelinesVersion()}`, bodyOk()], projectRoot());
    assert(parsed.status === "EXCEPTION", "Expected EXCEPTION");
    assert(parsed.errors[0].code === "PIPELINE_CYCLE", "Expected PIPELINE_CYCLE");
  } finally {
    rmrf(libDir);
    rmrf(path.join(rulesRoot(), "pipelines", pipelinesVersion(), "_engine_tests"));
  }

  console.log("✅ Engine core suite passed");
}

module.exports = { runEngineSuite };
