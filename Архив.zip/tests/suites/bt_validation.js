const path = require("path");
const { assert, runEngine } = require("../lib/utils");

function projectRoot() {
  return path.resolve(__dirname, "..", "..");
}

function expectFirstError(res, code, ruleId) {
  assert(res.status === "ERRORS" || res.status === "BLOCK" || res.status === "EXCEPTION", "Expected non-OK status");
  assert(res.errors && res.errors.length > 0, "Expected errors array");
  if (code) assert(res.errors[0].code === code, `Expected first error code ${code}, got ${res.errors[0].code}`);
  if (ruleId) assert(res.errors[0].rule_id === ruleId, `Expected first error rule_id ${ruleId}, got ${res.errors[0].rule_id}`);
}

async function runBtSuite() {
  console.log("\n== Suite 2: BT (pre-ABS) validation logic via pipelines ==");

  // UL_RESIDENT: missing INN -> ERR_INN_UL_PRESENT
  {
    const { parsed } = runEngine(["/ul_resident", "tests/fixtures/bt/ul_resident_missing_inn.json"], projectRoot());
    expectFirstError(parsed, "ERR_INN_UL_PRESENT", "libriary.inn.err_inn_ul_present");
  }

  // UL_NONRESIDENT: missing latin full name -> ERR_FULL_NAME_LAT_PRESENT
  {
    const { parsed } = runEngine(["/ul_nonresident", "tests/fixtures/bt/ul_nonresident_missing_latname.json"], projectRoot());
    expectFirstError(parsed, "ERR_FULL_NAME_LAT_PRESENT", "libriary.name.err_full_name_lat_present");
  }

  // IP_RESIDENT: missing OGRNIP -> ERR_OGRNIP_PRESENT
  {
    const { parsed } = runEngine(["/ip_resident", "tests/fixtures/bt/ip_resident_missing_ogrnip.json"], projectRoot());
    expectFirstError(parsed, "ERR_OGRNIP_PRESENT", "libriary.ogrn.err_ogrnip_present");
  }

  // IP_NONRESIDENT: missing both INN and KIO -> ERR_INN_OR_KIO_PRESENT
  {
    const { parsed } = runEngine(["/ip_nonresident", "tests/fixtures/bt/ip_nonresident_missing_inn_kio.json"], projectRoot());
    expectFirstError(parsed, "ERR_INN_OR_KIO_PRESENT", "libriary.inn.err_inn_or_kio_present");
  }

  // FL_RESIDENT: missing birth date -> ERR_BIRTH_DATE_PRESENT
  {
    const { parsed } = runEngine(["/fl_resident", "tests/fixtures/bt/fl_resident_missing_birth_date.json"], projectRoot());
    expectFirstError(parsed, "ERR_BIRTH_DATE_PRESENT", "libriary.birth.err_birth_date_present");
  }

  // FL_NONRESIDENT: missing id document type code -> ERR_ID_DOC_TYPE_CODE_PRESENT
  {
    const { parsed } = runEngine(["/fl_nonresident", "tests/fixtures/bt/fl_nonresident_missing_id_type.json"], projectRoot());
    expectFirstError(parsed, "ERR_ID_DOC_TYPE_CODE_PRESENT", "libriary.id.err_id_doc_type_code_present");
  }

  // Common requirement: contacts for UL -> ERR_CONTACTS_UL_ANY_FILLED
  {
    const { parsed } = runEngine(["/ul_resident", "tests/fixtures/bt/ul_resident_no_contacts.json"], projectRoot());
    expectFirstError(parsed, "ERR_CONTACTS_UL_ANY_FILLED", "libriary.contacts.err_contacts_ul_any_filled");
  }

  console.log("✅ BT validation suite passed");
}

module.exports = { runBtSuite };
